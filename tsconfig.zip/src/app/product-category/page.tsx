import Footer from "../components/Footer";
import Navbar from "../components/Navbar/Navbar";

const ProductCategory = () => {
    return(
        <>
        <Navbar />
        <section>
        </section>
        <Footer />
        </>
    )
}
export default ProductCategory;